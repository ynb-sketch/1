import "./index.css";
import MY_IMAGE from './assets/image.png';

const jsImageHTML = document.createElement('img')
jsImageHTML.src = MY_IMAGE
document.body.append(jsImageHTML)

console.log('Hello World!');